#!/bin/bash

WARP_ACCESS_KEY=admin WARP_SECRET_KEY=admin1234! warp mixed --warp-client warp1:7761 --host host1:9001 --duration=10s --autoterm --tls --insecure
