How to deploy a DAO node ?

1. Pre-requites : install nodejs via nvm and install pm2 on all NUC nodes
	# wget -qO- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.1/install.sh | bash
	# source ~/.bashrc
	# nvm ls-remote
	# nvm ls
	# nvm install lts/hydrogen
	# npm install -g pm2
	# pm2 install pm2-logrotate

2. Run installation script
	# ./install.sh 

3. Manage process
	# pm2 ps
	# pm2 logs
	# pm2 stop daod
	# pm2 start daod
	# pm2 restart daod
