How to deploy a DAO node ?

1. Pre-requites : install nodejs via nvm and install pm2 on all NUC nodes
     - install nvm
	# wget -qO- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.1/install.sh | bash
	# source ~/.bashrc

     - install nodejs
	# nvm ls-remote
	# nvm ls
	# nvm install lts/hydrogen

     - install pm2
	# npm install -g pm2
	# pm2 install pm2-logrotate
	# apt install golang-cfssl

2. create certificates
	# cd certs
	# vi server.json
	  >>> Change IP address in hosts
	# ./generate.sh
	# cd ..

3. Run installation script
	# ./install.sh 

4. Manage process
	# pm2 ps
	# pm2 logs
