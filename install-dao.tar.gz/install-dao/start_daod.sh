#!/bin/bash

cd /root/config/dao

export DAO_KMS_KES_KEY_FILE=/root/config/dao/certs/app.key
export DAO_KMS_KES_CERT_FILE=/root/config/dao/certs/app.cert
export DAO_KMS_KES_KEY_NAME=my-app-key
export DAO_KMS_KES_ENDPOINT=https://43.155.174.200:7373

# DAO_SERVER_URL=https://vault.daosolution.io DAO_ROOT_USER=admin DAO_ROOT_PASSWORD=admin1234! daod server --address "0.0.0.0:9000" --console-address "0.0.0.0:9999" http://192.168.0.41:9000/data http://192.168.0.33:9000/data http://192.168.0.54:9000/data http://192.168.0.55:9000/data

DAO_ROOT_USER=admin DAO_ROOT_PASSWORD=admin1234! daod server --console-address 0.0.0.0:8080 /data/minio-data
