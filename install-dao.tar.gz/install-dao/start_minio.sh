#!/bin/bash

cd /root/config/minio

export MINIO_KMS_KES_KEY_FILE=/root/config/certs/app.key
export MINIO_KMS_KES_CERT_FILE=/root/config/certs/app.cert
export MINIO_KMS_KES_KEY_NAME=my-app-key
export MINIO_KMS_KES_ENDPOINT=https://43.155.174.200:7373

# MINIO_SERVER_URL=https://vault.daosolution.io MINIO_ROOT_USER=admin MINIO_ROOT_PASSWORD=admin1234! minio server --address "0.0.0.0:9001" --console-address "0.0.0.0:8080" http://192.168.0.41:9001/minio-data http://192.168.0.33:9001/minio-data http://192.168.0.54:9001/minio-data http://192.168.0.55:9001/minio-data

MINIO_ROOT_USER=admin MINIO_ROOT_PASSWORD=admin1234! minio server --address ":9001" --console-address ":8081" /data/minio-data
