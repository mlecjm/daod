#!/bin/sh

mkdir -p ~/.dao/certs/CAs
cp ./certs/ca.pem ~/.dao/certs/CAs

cp ./bianries/daod /usr/local/bin
cp ./bianries/warp /usr/local/bin
cp ./bianries/dc /usr/local/bin

pm2 start pm2.daod.json
pm2 save
pm2 startup
