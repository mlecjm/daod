#!/bin/sh

mkdir -p ~/.dao/certs/CAs
cp ./certs/ca.pem ~/.dao/certs/CAs

mkdir -p ~/.minio/certs/CAs
cp ./certs/ca.pem ~/.minio/certs/CAs

cp ./binaries/daod /usr/local/bin
cp ./binaries/dc /usr/local/bin
cp ./binaries/minio /usr/local/bin
cp ./binaries/mc /usr/local/bin
cp ./binaries/warp /usr/local/bin

mkdir -p /root/config/certs
cp ./certs/server-key.pem /root/config/certs
cp ./certs/server.pem /root/config/certs
cp ./certs/app.key /root/config/certs
cp ./certs/app.cert /root/config/certs

mkdir -p /root/config/dao
cp pm2.daod.json /root/config/dao
cp start_daod.sh /root/config/dao

mkdir -p /root/config/minio
cp pm2.minio.json /root/config/minio
cp start_minio.sh /root/config/minio

mkdir -p /root/config/warp
cp pm2.warp.json /root/config/warp

cd ~/.dao/certs
ln -s /root/config/certs/server-key.pem private.key
ln -s /root/config/certs/server.pem public.crt

cd ~/.minio/certs
ln -s /root/config/certs/server-key.pem private.key
ln -s /root/config/certs/server.pem public.crt

cd /root/config/dao
pm2 start pm2.daod.json

cd /root/config/minio
pm2 start pm2.minio.json

cd /root/config/warp
pm2 start pm2.warp.json

pm2 save
pm2 startup

cp -dpR ./speedtest /root

