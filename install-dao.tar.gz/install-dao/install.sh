#!/bin/sh

mkdir -p ~/.dao/certs/CAs
cp ./certs/ca.pem ~/.dao/certs/CAs

cp ./bianries/daod /usr/local/bin
cp ./bianries/warp /usr/local/bin
cp ./bianries/dc /usr/local/bin

mkdir -p /root/config/dao
cp -dpR ./certs /root/config/dao
cp pm2.daod.jso /root/config/dao
cp start_daod.sh /root/config/dao

cd /root/config/dao

pm2 start pm2.daod.json
pm2 save
pm2 startup
